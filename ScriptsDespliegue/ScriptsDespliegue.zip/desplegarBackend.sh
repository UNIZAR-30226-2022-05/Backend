#!/bin/bash

IP_AZURE="unoforall.westeurope.cloudapp.azure.com"
USUARIO="azureuser"
DIRECTORIO_REMOTO="unoforall"

ssh ${USUARIO}@${IP_AZURE} echo ""
if [ $? == 255 ]
then
	echo "La máquina Azure no se encuentra disponible" 1>&2
	exit 1
fi

cd ..

ssh ${USUARIO}@${IP_AZURE} rm -rf "~/${DIRECTORIO_REMOTO}"
ssh ${USUARIO}@${IP_AZURE} mkdir -p "~/${DIRECTORIO_REMOTO}/target"
ssh ${USUARIO}@${IP_AZURE} mkdir -p "~/${DIRECTORIO_REMOTO}/PostgreSQL"

scp Proyecto/target/backend-0.0.1-SNAPSHOT.jar ${USUARIO}@${IP_AZURE}:~/${DIRECTORIO_REMOTO}/target/
scp Proyecto/credenciales.properties ${USUARIO}@${IP_AZURE}:~/${DIRECTORIO_REMOTO}/

cd "Scripts PostgreSQL"
unzip -f scripts.zip
scp main.zip ${USUARIO}@${IP_AZURE}:~/${DIRECTORIO_REMOTO}/PostgreSQL/
scp import_postgreSQL_database.sh ${USUARIO}@${IP_AZURE}:~/${DIRECTORIO_REMOTO}/PostgreSQL/
scp start_postgreSQL.sh ${USUARIO}@${IP_AZURE}:~/${DIRECTORIO_REMOTO}/PostgreSQL/
scp stop_postgreSQL.sh ${USUARIO}@${IP_AZURE}:~/${DIRECTORIO_REMOTO}/PostgreSQL/
cd ..

ssh ${USUARIO}@${IP_AZURE} chmod u+x "~/${DIRECTORIO_REMOTO}/PostgreSQL/*.sh"
ssh ${USUARIO}@${IP_AZURE} "cd ~/${DIRECTORIO_REMOTO}/PostgreSQL/ ; ./import_postgreSQL_database.sh < /dev/null"


if [ $? == 0 ]
then
	echo "El despliegue se ha realizado con éxito"
else
	echo "El despliegue ha fallado"
fi




