#!/bin/bash

IP_AZURE="unoforall.westeurope.cloudapp.azure.com"
USUARIO="azureuser"
DIRECTORIO_REMOTO="unoforall"

ssh ${USUARIO}@${IP_AZURE} "~/${DIRECTORIO_REMOTO}/PostgreSQL/start_postgreSQL.sh"
ssh ${USUARIO}@${IP_AZURE} "java -jar ~/${DIRECTORIO_REMOTO}"
