#!/bin/bash

IP_AZURE="unoforall.westeurope.cloudapp.azure.com"
USUARIO="azureuser"
DIRECTORIO_REMOTO="unoforall"

ssh ${USUARIO}@${IP_AZURE} echo ""
if [ $? == 255 ]
then
	echo "La máquina Azure no se encuentra disponible" 1>&2
	exit 1
fi

echo "Liberando puertos ..."
ssh ${USUARIO}@${IP_AZURE} 'pid=$(sudo lsof -i:80 -Fp | head -n 1 | sed "s/^p//") ; sudo kill -9 $pid &> /dev/null'

echo "Iniciando PostgreSQL ..."
ssh ${USUARIO}@${IP_AZURE} "~/${DIRECTORIO_REMOTO}/PostgreSQL/start_postgreSQL.sh"

echo "Iniciando Backend ..."
ssh ${USUARIO}@${IP_AZURE} "cd ~/${DIRECTORIO_REMOTO}/target ; sudo java -jar backend-0.0.1-SNAPSHOT.jar"
