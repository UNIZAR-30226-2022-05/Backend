#!/bin/bash

IP_AZURE="unoforall.westeurope.cloudapp.azure.com"
USUARIO="azureuser"
DIRECTORIO_REMOTO="unoforall"

echo "Advertencia: La máquina de Azure se apagará por completo"
echo "Pulsa ENTER para continuar"
read

ssh ${USUARIO}@${IP_AZURE} echo ""
if [ $? == 255 ]
then
	echo "La máquina Azure no se encuentra disponible" 1>&2
	exit 1
fi

ssh ${USUARIO}@${IP_AZURE} "sudo poweroff"
