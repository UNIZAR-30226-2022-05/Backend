#!/bin/bash

IP_AZURE="unoforall.westeurope.cloudapp.azure.com"
USUARIO="azureuser"
DIRECTORIO_REMOTO="unoforall"

ssh ${USUARIO}@${IP_AZURE} "sudo poweroff"
